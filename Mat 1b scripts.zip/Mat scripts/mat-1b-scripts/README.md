# Mat 1b scripts

Vi laver scripts til mat 1b eksamen...

Se hvad du skal lave på [Sheets](https://docs.google.com/spreadsheets/d/1CjMm61H9h0et4TOVBfbzOLN9wFFUHEJ0XHEkXBxGJuQ/edit) og så lav et dokument så man kan løse alle store- og lilledags opgaver den uge, men ikke bare gentag for opgaver der er ens.

## Opsætning

Jupyter Notebooks er ikke gode venner med git, så du skal lige tilføje nbstripout til repo'et når du begynder.

Hvis du ikke har installeret det før kan du gøre det med:

```sh
pip install --upgrade nbstripout
```

Og så inde i mappen, hvor den her fil kører du så:

```sh
nbstripout --install
```

Det var alt. Du er good to go.
